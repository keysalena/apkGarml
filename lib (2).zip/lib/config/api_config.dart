class ApiConfig {
  static const String baseUrl = 'http://10.60.104.126:8000/api';
  // static const String baseUrl = 'https://garmloak.xo.je/api';
}