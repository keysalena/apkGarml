import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';

import 'config/api_config.dart';
import 'materi_read_screen.dart';

class ModuleDetailScreen extends StatefulWidget {
  final String moduleId;
  final String moduleTitle;

  const ModuleDetailScreen({
    super.key,
    required this.moduleId,
    required this.moduleTitle,
  });

  @override
  State<ModuleDetailScreen> createState() => _ModuleDetailScreenState();
}

class _ModuleDetailScreenState extends State<ModuleDetailScreen> {
  bool _isLoading = true;
  Map<String, dynamic>? _moduleData;

  // Variabel untuk memisahkan pendahuluan dan materi reguler
  Map<String, dynamic>? _pendahuluan;
  List<dynamic> _regularMateri = [];

  @override
  void initState() {
    super.initState();
    _fetchModuleDetail();
  }

  Future<void> _fetchModuleDetail() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      if (token == null) return;

      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/modules/${widget.moduleId}'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && mounted) {
          setState(() {
            _moduleData = data['data'];

            // Tangkap langsung dari API
            _pendahuluan = _moduleData!['pendahuluan'];
            _regularMateri = _moduleData!['materi'];

            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  IconData _getMateriIcon(String tipe) {
    switch (tipe.toLowerCase()) {
      case 'video':
        return Icons.play_circle_fill_rounded;
      case 'pdf':
        return Icons.picture_as_pdf_rounded;
      default:
        return Icons.article_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: Text(
          widget.moduleTitle,
          style: const TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: primaryGreen))
          : _moduleData == null
          ? const Center(child: Text('Gagal memuat modul.'))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ==========================================
                  // 1. JUDUL MODUL
                  // ==========================================
                  Text(
                    _moduleData!['judul'],
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _moduleData!['deskripsi'] ??
                        'Silakan pelajari materi berikut secara berurutan.',
                    style: const TextStyle(fontSize: 14, color: Colors.black54),
                  ),
                  const SizedBox(height: 24),

                  // ==========================================
                  // 2. PENDAHULUAN (Kuis Singkat - HTML Text)
                  // ==========================================
                  if (_pendahuluan != null &&
                      _pendahuluan!['konten_teks'] != null) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.blue.shade100),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start, // Tambahkan ini agar ikon tetap di atas jika teks jadi 2 baris
                            children: [
                              Icon(
                                Icons.lightbulb_outline_rounded,
                                color: Colors.blue.shade700,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                // <-- TAMBAHKAN EXPANDED DI SINI
                                child: Text(
                                  _pendahuluan!['judul'],
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.blue.shade800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          // Render HTML dari CKEditor
                          HtmlWidget(
                            _pendahuluan!['konten_teks'] ?? '',
                            textStyle: const TextStyle(
                              fontSize: 14.0,
                              color: Colors.black87,
                            ),
                            customStylesBuilder: (element) {
                              if (element.localName == 'table') {
                                return {
                                  'border': '1px solid grey',
                                  'background-color': 'white',
                                };
                              }
                              return null;
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                  ],

                  // ==========================================
                  // 3. DAFTAR MATERI REGULER
                  // ==========================================
                  const Text(
                    'Daftar Materi',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 16),

                  if (_regularMateri.isNotEmpty)
                    ..._regularMateri.map((materi) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: ListTile(
                          leading: Icon(
                            _getMateriIcon(materi['tipe']),
                            color: primaryGreen,
                            size: 30,
                          ),
                          title: Text(
                            materi['judul'],
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                          trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey),
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MateriReadScreen(materi: materi),
                                  ),
                                ).then((_) {
                                  // KODE INI BERJALAN OTOMATIS SAAT USER KEMBALI DARI BACA MATERI
                                  _fetchModuleDetail(); 
                                });
                              },
                        ),
                      );
                    })
                  else
                    const Text(
                      'Belum ada materi di modul ini.',
                      style: TextStyle(color: Colors.grey),
                    ),

                  const SizedBox(height: 40),

                  // ==========================================
                  // 4. KUIS / EVALUASI AKHIR (Dari tabel Questions)
                  // ==========================================
                  const Divider(),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.orange.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.emoji_events_rounded,
                          color: Colors.orange,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Evaluasi Modul',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              'Uji pemahamanmu dan dapatkan XP',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.black54,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  if (_moduleData!['kuis'] != null &&
                      _moduleData!['kuis'].isNotEmpty)
                    ElevatedButton(
                      onPressed: () {
                        // TODO: Mengerjakan Kuis
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('Mulai Kuis Sekarang'),
                    )
                  else
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'Kuis belum tersedia.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}
