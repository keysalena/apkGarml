import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'config/api_config.dart';

class HomeScreen extends StatefulWidget {
  // 1. Daftarkan parameter onNavigate di sini
  final Function(int)? onNavigate;

  // 2. Tambahkan ke dalam constructor
  const HomeScreen({super.key, this.onNavigate});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isLoading = true;
  String _nama = 'Memuat...';
  int _level = 1;
  int _xp = 0;
  int _xpTarget = 100;

  Map<String, dynamic>? _lastModule;

  @override
  void initState() {
    super.initState();
    _fetchHomeData();
  }

  Future<void> _fetchHomeData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');

      if (token == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      // Sesuaikan IP ini (10.0.2.2 untuk Emulator Android, atau IP lokal untuk HP fisik)
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/home'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && mounted) {
          setState(() {
            final user = data['data']['user'];
            _nama = user['nama'] ?? 'Pengguna';
            _level = user['level'] ?? 1;
            _xp = user['xp'] ?? 0;
            _xpTarget = user['xp_target'] ?? 500;

            _lastModule = data['data']['last_module'];
            _isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: Colors.white,
      // ==========================================
      // APP BAR SESUAI DESAIN
      // ==========================================
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: const Text(
          'Beranda',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: primaryGreen))
          : RefreshIndicator(
              color: primaryGreen,
              onRefresh: _fetchHomeData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(
                  horizontal: 20.0,
                  vertical: 10.0,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ==========================================
                    // SECTION 1: PROFIL & XP PROGRESS
                    // ==========================================
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 35,
                          backgroundImage: NetworkImage(
                            'https://ui-avatars.com/api/?name=${Uri.encodeComponent(_nama)}&background=random',
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Halo, ${_nama.split(' ')[0]}!',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Level $_level',
                                style: TextStyle(
                                  color: primaryGreen,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(height: 8),
                              // Label XP di atas bar
                              Text(
                                '$_xp / $_xpTarget XP',
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 4),
                              // Bar XP Tebal dan Bulat
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: LinearProgressIndicator(
                                  value: _xpTarget > 0 ? _xp / _xpTarget : 0,
                                  backgroundColor: Colors.orange.shade100,
                                  color: Colors.orange,
                                  minHeight: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        // Badge Icon (Bisa diganti image asset asli)
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.orange.shade50,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.stars_rounded,
                            color: Colors.orange,
                            size: 40,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),

                    // ==========================================
                    // SECTION 2: LANJUTKAN BELAJAR
                    // ==========================================
                    const Text(
                      'Lanjutkan Belajar',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),

                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(
                          0xFFF4F7FC,
                        ), // Warna biru keabuan muda
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _lastModule != null
                                      ? 'Modul ${_lastModule!['urutan']}'
                                      : 'Belum Ada Modul',
                                  style: const TextStyle(
                                    color: Colors.black87,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  _lastModule != null
                                      ? _lastModule!['judul']
                                      : 'Mulai perjalanan belajarmu sekarang.',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.black54,
                                  ),
                                ),
                                const SizedBox(height: 16),

                                if (_lastModule != null) ...[
                                  // 1. Ambil nilainya dan pastikan bertipe double secara aman
                                  Builder(
                                    builder: (context) {
                                      final double progressValue =
                                          (_lastModule!['progress'] as num?)
                                              ?.toDouble() ??
                                          0.0;

                                      return Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            // 2. Kalikan 100 untuk teks (Contoh: 0.5 * 100 = 50%)
                                            '${(progressValue * 100).toInt()}%',
                                            style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold,
                                              color: primaryGreen,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                            child: LinearProgressIndicator(
                                              // 3. Masukkan nilai aslinya (0.0 sampai 1.0) langsung ke value
                                              value: progressValue,
                                              backgroundColor:
                                                  Colors.grey.shade300,
                                              color: primaryGreen,
                                              minHeight: 6,
                                            ),
                                          ),
                                        ],
                                      );
                                    },
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          // Tempat Image 3D (Ganti dengan Image.asset jika ada)
                          Expanded(
                            flex: 1,
                            child: Icon(
                              Icons.dns_rounded,
                              size: 70,
                              color: Colors.blueGrey.shade300,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),

                    // ==========================================
                    // SECTION 3: AKSI CEPAT (2x2 GRID)
                    // ==========================================
                    const Text(
                      'Aksi Cepat',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),

                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.4, // Mengatur rasio lebar:tinggi kartu agar proporsional
                      children: [
                        _buildQuickActionCard(
                          context,
                          icon: Icons.view_day_rounded,
                          label: 'Modul',
                          color: primaryGreen,
                          onTap: () {
                            if (widget.onNavigate != null) {
                              widget.onNavigate!(1);
                            }
                          },
                        ),
                        _buildQuickActionCard(
                          context,
                          icon: Icons.view_in_ar_rounded,
                          label: 'AR Scan',
                          color: Colors.purple.shade400,
                          onTap: () {},
                        ),
                        _buildQuickActionCard(
                          context,
                          icon: Icons.show_chart_rounded,
                          label: 'Progress',
                          color: Colors.orange.shade500,
                          onTap: () {},
                        ),
                        _buildQuickActionCard(
                          context,
                          icon: Icons.person_rounded,
                          label: 'Profil',
                          color: Colors.blue.shade600,
                          onTap: () {},
                        ),
                      ],
                    ),
                    const SizedBox(height: 20), // Spacing bawah
                  ],
                ),
              ),
            ),
    );
  }

  // Komponen Kartu Aksi Cepat (Desain Kotak Besar)
  Widget _buildQuickActionCard(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade200),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withValues(
                  alpha: 0.1,
                ), // Background transparan menyesuaikan warna ikon
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
