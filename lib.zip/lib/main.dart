import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth/login_screen.dart'; // Sesuaikan path ini dengan lokasi file LoginScreen Anda
import 'main_screen.dart';

void main() async {
  // Wajib ditambahkan jika fungsi main() menggunakan 'async'
  WidgetsFlutterBinding.ensureInitialized();

  // Mengecek apakah ada token yang tersimpan di memori HP
  final prefs = await SharedPreferences.getInstance();
  final String? token = prefs.getString('auth_token');

  // Tentukan halaman pertama yang akan dibuka
  Widget initialScreen;
  if (token != null && token.isNotEmpty) {
    initialScreen = const MainScreen(); // Token ada -> Langsung masuk aplikasi
  } else {
    initialScreen = const LoginScreen(); // Token tidak ada -> Harus login dulu
  }

  runApp(MyApp(initialScreen: initialScreen));
}

class MyApp extends StatelessWidget {
  final Widget initialScreen; // Menerima parameter halaman awal

  const MyApp({super.key, required this.initialScreen});

  @override
  Widget build(BuildContext context) {
    const Color primaryGreen = Color(0xFF1E8F4E); 

    return MaterialApp(
      title: 'E-Learning Gamification',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: primaryGreen,
          primary: primaryGreen,
          background: Colors.white,
        ),
        scaffoldBackgroundColor: Colors.white,
        textTheme: GoogleFonts.poppinsTextTheme(), 
        
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryGreen,
            foregroundColor: Colors.white,
            elevation: 0,
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontSize: 16, 
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.grey[50],
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: primaryGreen, width: 2),
          ),
          labelStyle: TextStyle(color: Colors.grey[600]),
        ),
      ),
      // Set halaman awal berdasarkan hasil pengecekan di fungsi main()
      home: initialScreen, 
    );
  }
}