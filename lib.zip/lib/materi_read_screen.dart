import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config/api_config.dart';
import 'package:url_launcher/url_launcher.dart';

class MateriReadScreen extends StatefulWidget {
  final Map<String, dynamic> materi;

  const MateriReadScreen({super.key, required this.materi});

  @override
  State<MateriReadScreen> createState() => _MateriReadScreenState();
}

class _MateriReadScreenState extends State<MateriReadScreen> {
  bool _isSubmitting = false;
  bool _isCompleted = false; // Status apakah materi sudah selesai

  @override
  void initState() {
    super.initState();
    _checkCompletionStatus();
  }

  // Mengecek apakah materi ini sudah pernah diselesaikan sebelumnya
  Future<void> _checkCompletionStatus() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> completedMateri = prefs.getStringList('completed_materi') ?? [];
    
    if (completedMateri.contains(widget.materi['materi_id'].toString())) {
      setState(() => _isCompleted = true);
    }
  }

  IconData _getMateriIcon(String tipe) {
    switch (tipe.toLowerCase()) {
      case 'video': return Icons.play_circle_fill_rounded;
      case 'pdf': return Icons.picture_as_pdf_rounded;
      default: return Icons.article_rounded;
    }
  }

  Future<void> _selesaikanMateri() async {
    setState(() => _isSubmitting = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      
      if (token == null) return;

      final materiId = widget.materi['materi_id'].toString();
      
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/materi/$materiId/complete'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['success'] == true) {
        final int xpGained = data['data']['xp_gained'];
        final bool isLevelUp = data['data']['is_level_up'];
        final int newLevel = data['data']['level'];

        // Simpan status selesai ke memori HP agar tombol tetap terkunci saat halaman dibuka ulang
        List<String> completedMateri = prefs.getStringList('completed_materi') ?? [];
        if (!completedMateri.contains(materiId)) {
          completedMateri.add(materiId);
          await prefs.setStringList('completed_materi', completedMateri);
        }

        if (mounted) {
          setState(() {
            _isCompleted = true; // Mengubah UI tombol menjadi disabled
          });

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  const Icon(Icons.stars_rounded, color: Colors.white),
                  const SizedBox(width: 10),
                  Text('+$xpGained XP! Materi diselesaikan.'),
                ],
              ),
              backgroundColor: Colors.orange.shade600,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          );

          if (isLevelUp) _showLevelUpDialog(newLevel);
        }
      } else {
        // Jika API menolak (misal: terdeteksi spam/sudah pernah selesai di database)
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['message'] ?? 'Materi sudah diselesaikan.')),
          );
          setState(() => _isCompleted = true);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal menyimpan progres jaringan.')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _showLevelUpDialog(int level) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        contentPadding: const EdgeInsets.all(24),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.military_tech, size: 80, color: Colors.amber),
            const SizedBox(height: 16),
            const Text(
              'LEVEL UP!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.orange),
            ),
            const SizedBox(height: 8),
            Text(
              'Selamat! Kamu telah mencapai Level $level.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                minimumSize: const Size(double.infinity, 45),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
              ),
              child: const Text('Lanjutkan Belajar', style: TextStyle(color: Colors.white)),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Theme.of(context).primaryColor;
    final String tipe = widget.materi['tipe'] ?? 'teks';

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Materi Belajar',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
      
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: ElevatedButton.icon(
            // Kunci tombol jika _isCompleted bernilai TRUE
            onPressed: (_isCompleted || _isSubmitting) ? null : _selesaikanMateri,
            icon: _isSubmitting 
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Icon(_isCompleted ? Icons.check_circle : Icons.check_circle_outline),
            label: Text(_isSubmitting 
                ? 'Menyimpan...' 
                : _isCompleted ? 'Materi Selesai' : 'Selesai & Dapatkan XP'),
            style: ElevatedButton.styleFrom(
              // Ubah warna menjadi abu-abu jika sudah selesai
              backgroundColor: _isCompleted ? Colors.grey.shade400 : primaryGreen,
              disabledBackgroundColor: Colors.grey.shade300,
              disabledForegroundColor: Colors.grey.shade600,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ),
      ),
      
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(_getMateriIcon(tipe), color: primaryGreen, size: 28),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    tipe.toUpperCase(),
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey.shade700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              widget.materi['judul'] ?? 'Tanpa Judul',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
            const Divider(height: 40),

            if (tipe == 'teks' || tipe == 'pendahuluan') ...[
              HtmlWidget(
                widget.materi['konten_teks'] ?? '<p>Tidak ada konten teks.</p>',
                textStyle: const TextStyle(fontSize: 15.0, color: Colors.black87, height: 1.6),
                customStylesBuilder: (element) {
                  if (element.localName == 'table') {
                    return {'border': '1px solid grey', 'width': '100%'};
                  }
                  return null;
                },
              ),
            ] else ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: tipe == 'video' ? Colors.red.shade50 : Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: tipe == 'video' ? Colors.red.shade100 : Colors.orange.shade100,
                    width: 2,
                  ),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          )
                        ]
                      ),
                      child: Icon(
                        _getMateriIcon(tipe), 
                        size: 64, 
                        color: tipe == 'video' ? Colors.red.shade400 : Colors.orange.shade400
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      tipe == 'video' ? 'Materi Video' : 'Dokumen PDF',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold, 
                        color: tipe == 'video' ? Colors.red.shade900 : Colors.orange.shade900
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Tekan tombol di bawah untuk membuka dan mempelajari materi ini.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: tipe == 'video' ? Colors.red.shade700 : Colors.orange.shade700
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          // Ambil URL dari database (bisa link YouTube atau path storage)
                          final String? urlString = widget.materi['konten_url'];
                          
                          if (urlString != null && urlString.isNotEmpty) {
                            // Jika formatnya path storage Laravel, gabungkan dengan baseUrl
                            final String fullUrl = urlString.startsWith('http') 
                                ? urlString 
                                : '${ApiConfig.baseUrl.replaceAll('/api', '')}/$urlString';
                                
                            final Uri url = Uri.parse(fullUrl);
                            
                            if (await canLaunchUrl(url)) {
                              await launchUrl(url, mode: LaunchMode.externalApplication);
                            } else {
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Tidak dapat membuka tautan materi ini.')),
                                );
                              }
                            }
                          } else {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Tautan materi belum tersedia.')),
                              );
                            }
                          }
                        },
                        icon: Icon(tipe == 'video' ? Icons.play_arrow_rounded : Icons.file_download_rounded),
                        label: Text(tipe == 'video' ? 'Tonton Video' : 'Buka PDF'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: tipe == 'video' ? Colors.red.shade600 : Colors.orange.shade600,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }
}