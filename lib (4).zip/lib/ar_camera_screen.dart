import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ArCameraScreen extends StatefulWidget {
  final String arUrl;
  final String moduleTitle;

  const ArCameraScreen({
    super.key,
    required this.arUrl,
    required this.moduleTitle,
  });

  @override
  State<ArCameraScreen> createState() => _ArCameraScreenState();
}

class _ArCameraScreenState extends State<ArCameraScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setOnConsoleMessage((message) {
        print('WebView Console: ${message.message}');
      })
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (String url) {
            if (mounted) {
              setState(() => _isLoading = false);
            }
          },
          onWebResourceError: (WebResourceError error) {
            print('WebView Error: ${error.description}');
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.arUrl));
  }

  Future<void> _openInExternalBrowser() async {
    final uri = Uri.parse(widget.arUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak dapat membuka browser eksternal.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Latar belakang body tetap hitam untuk AR
      
      // 1. Navbar dengan warna putih senada dengan menu lainnya
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0, // Mencegah perubahan warna saat scroll
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black87), // Ikon menjadi hitam
        
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          tooltip: 'Kembali',
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'AR: ${widget.moduleTitle}',
          style: const TextStyle(
            color: Colors.black87, // Teks menjadi hitam
            fontSize: 16, 
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.open_in_browser_rounded),
            tooltip: 'Buka di Browser',
            onPressed: _openInExternalBrowser,
          ),
        ],
      ),
      
      // 2. Karena extendBodyBehindAppBar dihapus, Stack otomatis memiliki jarak (berada di bawah AppBar)
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          
          if (_isLoading)
            const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Colors.blue),
                  SizedBox(height: 16),
                  Text('Memuat Kamera AR...', style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}