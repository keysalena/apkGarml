class ApiConfig {
  static const String baseUrl = 'https://f3189a1b-3e72-4dd3-9283-a208f7681479.svc.dalang.io/api';
}