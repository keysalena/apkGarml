import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Untuk Haptic Feedback
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config/api_config.dart';

class MateriReadScreen extends StatefulWidget {
  final dynamic materi;
  final bool isCompleted; // status dari database (user_progress)

  const MateriReadScreen({
    super.key,
    required this.materi,
    this.isCompleted = false,
  });

  @override
  State<MateriReadScreen> createState() => _MateriReadScreenState();
}

class _MateriReadScreenState extends State<MateriReadScreen> {
  bool _isLoading = false;
  late bool _isCompleted;

  @override
  void initState() {
    super.initState();
    // Jika sudah selesai di database, tombol langsung disabled
    _isCompleted = widget.isCompleted;
  }

  String _resolveUrl(String url) {
    if (url.startsWith('http')) return url;
    final base = ApiConfig.baseUrl.replaceAll(RegExp(r'/api/?$'), '');
    final path = url.startsWith('/') ? url.substring(1) : url;
    return '$base/$path';
  }

  Future<void> _bukaUrl() async {
    final raw = widget.materi['konten_url']?.toString();
    if (raw == null || raw.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tautan materi belum tersedia.')),
      );
      return;
    }
    final ok = await launchUrl(
      Uri.parse(_resolveUrl(raw)),
      mode: LaunchMode.externalApplication,
    );
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tidak dapat membuka tautan.')),
      );
    }
  }

  Future<void> _selesaikanMateri() async {
    if (_isCompleted) return;

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      final materiId = widget.materi['materi_id'].toString();

      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/materi/$materiId/complete'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final result = data['data'] ?? {};
          final int xp = result['xp_gained'] ?? 0;

          setState(() {
            _isCompleted = true;
            _isLoading = false;
          });

          // xp = 0 berarti materi sudah pernah diselesaikan sebelumnya
          if (xp == 0) return;

          HapticFeedback.heavyImpact();
          _showRewardBottomSheet(
            xpGained: xp,
            isLevelUp: result['is_level_up'] ?? false,
            newLevel: result['level'] ?? 1,
          );
          return;
        }
      }

      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Gagal menyimpan progres. Silakan coba lagi.'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Terjadi kesalahan jaringan.')),
      );
    }
  }

  // UI Modal Bottom Sheet bergaya modern (Glass/Rounded)
  void _showRewardBottomSheet({
    required int xpGained,
    required bool isLevelUp,
    required int newLevel,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor:
          Colors.transparent, // Transparan agar ujung membulat terlihat
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(32),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Ikon Reward
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: isLevelUp
                      ? Colors.orange.shade50
                      : Colors.green.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isLevelUp ? Icons.emoji_events_rounded : Icons.stars_rounded,
                  size: 64,
                  color: isLevelUp ? Colors.orange : Colors.green,
                ),
              ),
              const SizedBox(height: 24),

              Text(
                isLevelUp ? 'Level Up!' : 'Luar Biasa!',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 8),

              Text(
                isLevelUp
                    ? 'Selamat! Kamu telah mencapai Level $newLevel.\n+$xpGained XP berhasil didapatkan.'
                    : 'Kamu berhasil menyelesaikan materi ini dan mendapatkan +$xpGained XP.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey.shade600,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Tutup modal
                    Navigator.pop(context); // Kembali ke daftar materi
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'Lanjutkan Belajar',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(
                height: 16,
              ), // Ruang ekstra untuk layar notch bawah
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Theme.of(context).primaryColor;
    final String tipe =
        widget.materi['tipe']?.toString().toLowerCase() ?? 'teks';

    return Scaffold(
      backgroundColor: Colors.white, // Putih bersih untuk mode baca
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: Column(
        children: [
          // ==========================================
          // 1. AREA KONTEN (Teks, Video, atau PDF)
          // ==========================================
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Label Tipe Materi
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      tipe.toUpperCase(),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Judul Materi
                  Text(
                    widget.materi['judul'] ?? 'Tanpa Judul',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Logika Render Konten Berdasarkan Tipe
                  if (tipe == 'teks') ...[
                    HtmlWidget(
                      widget.materi['konten_teks'] ??
                          '<p>Tidak ada konten.</p>',
                      textStyle: TextStyle(
                        fontSize: 16,
                        color: Colors.black.withValues(alpha: 0.8),
                        height: 1.8,
                      ),
                    ),
                  ] else ...[
                    _buildMediaCard(tipe, primaryGreen),
                  ],
                ],
              ),
            ),
          ),

          // ==========================================
          // 2. STICKY BOTTOM BUTTON (Dipaku di bawah)
          // ==========================================
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Colors.grey.shade100)),
            ),
            child: SafeArea(
              child: ElevatedButton(
                onPressed: _isCompleted || _isLoading
                    ? null
                    : _selesaikanMateri,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isCompleted
                      ? Colors.grey.shade200
                      : primaryGreen,
                  foregroundColor: _isCompleted
                      ? Colors.grey.shade600
                      : Colors.white,
                  disabledBackgroundColor: Colors.grey.shade200,
                  disabledForegroundColor: Colors.grey.shade500,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            _isCompleted
                                ? Icons.check_circle_rounded
                                : Icons.star_rounded,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _isCompleted
                                ? 'Materi Selesai'
                                : 'Selesai & Dapatkan XP',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Desain Kartu Raksasa untuk Materi Video atau PDF
  Widget _buildMediaCard(String tipe, Color primaryGreen) {
    final isVideo = tipe == 'video';
    final Color cardColor = isVideo
        ? Colors.pink.shade50
        : Colors.orange.shade50;
    final Color iconColor = isVideo
        ? Colors.pink.shade400
        : Colors.orange.shade400;
    final IconData iconData = isVideo
        ? Icons.play_circle_fill_rounded
        : Icons.picture_as_pdf_rounded;
    final String actionText = isVideo
        ? 'Tonton Video Penuh'
        : 'Buka Dokumen PDF';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 24),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        children: [
          Icon(iconData, size: 80, color: iconColor),
          const SizedBox(height: 24),
          Text(
            isVideo
                ? 'Materi Pembelajaran Interaktif'
                : 'Dokumen Bacaan Pendukung',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: isVideo ? Colors.pink.shade900 : Colors.orange.shade900,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tekan tombol di bawah untuk membuka materi ini di aplikasi eksternal.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: isVideo ? Colors.pink.shade700 : Colors.orange.shade700,
            ),
          ),
          const SizedBox(height: 32),
          ElevatedButton.icon(
            onPressed: () {
              HapticFeedback.lightImpact();
              _bukaUrl();
            },
            icon: const Icon(Icons.open_in_new_rounded, size: 18),
            label: Text(
              actionText,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: iconColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 0,
            ),
          ),
        ],
      ),
    );
  }
}
