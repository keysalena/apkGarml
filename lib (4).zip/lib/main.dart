import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth/login_screen.dart';
import 'main_screen.dart';
import 'theme/app_theme.dart';

void main() async {
  // Wajib ditambahkan jika fungsi main() menggunakan 'async'
  WidgetsFlutterBinding.ensureInitialized();

  // Mengecek apakah ada token yang tersimpan di memori HP
  final prefs = await SharedPreferences.getInstance();
  final String? token = prefs.getString('auth_token');

  // Tentukan halaman pertama yang akan dibuka
  final Widget initialScreen = (token != null && token.isNotEmpty)
      ? const MainScreen() // Token ada -> Langsung masuk aplikasi
      : const LoginScreen(); // Token tidak ada -> Harus login dulu

  runApp(MyApp(initialScreen: initialScreen));
}

class MyApp extends StatelessWidget {
  final Widget initialScreen; // Menerima parameter halaman awal

  const MyApp({super.key, required this.initialScreen});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'E-Learning Gamification',
      debugShowCheckedModeBanner: false,
      // Tema kini terpusat di theme/app_theme.dart, tidak lagi
      // didefinisikan inline di sini.
      theme: AppTheme.theme,
      home: initialScreen,
    );
  }
}
