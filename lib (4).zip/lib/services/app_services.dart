import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../auth/login_screen.dart';
import '../config/api_config.dart';

/// Navigator global supaya logout bisa dilakukan dari mana saja (tanpa context).
final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

/// Kunci cache lokal (dihapus saat login/logout agar data antar-akun tidak tercampur).
const List<String> _cacheKeys = ['cache_home', 'cache_profile', 'cache_modules'];

/// Mengubah path avatar dari backend menjadi URL lengkap.
/// Mendukung dua bentuk: path mentah ("avatars/x.jpg") ATAU URL penuh.
String? resolveAvatarUrl(String? raw) {
  if (raw == null || raw.isEmpty) return null;
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  final root = ApiConfig.baseUrl.replaceAll(RegExp(r'/api/?$'), '');
  return '$root/storage/$raw';
}

/// State global ringan: penanda "data berubah" dan tab yang sedang aktif.
class AppSession {
  AppSession._();
  static final AppSession instance = AppSession._();

  /// Naik setiap kali ada perubahan data (XP, materi selesai, profil, avatar).
  /// Home / Modul / Profil mendengarkan ini lalu refresh diam-diam.
  final ValueNotifier<int> dataVersion = ValueNotifier<int>(0);

  /// Tab aktif di MainScreen.
  final ValueNotifier<int> tabIndex = ValueNotifier<int>(0);

  void notifyDataChanged() => dataVersion.value++;

  bool _loggingOut = false;

  /// Logout paksa (token benar-benar tidak valid). Aman dipanggil berkali-kali.
  Future<void> forceLogout() async {
    if (_loggingOut) return;
    _loggingOut = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('auth_token');
      await prefs.remove('completed_materi');
      await LocalCache.clearAll();
      tabIndex.value = 0;

      appNavigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    } finally {
      // Beri jeda singkat agar request lain yang masih berjalan tidak memicu logout ganda.
      Future.delayed(const Duration(seconds: 1), () => _loggingOut = false);
    }
  }
}

/// Cache JSON sederhana di SharedPreferences.
class LocalCache {
  static Future<void> save(String key, dynamic data) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(key, jsonEncode(data));
    } catch (_) {}
  }

  static Future<dynamic> load(String key) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(key);
      if (raw == null) return null;
      return jsonDecode(raw);
    } catch (_) {
      return null;
    }
  }

  static Future<void> clearAll() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      for (final k in _cacheKeys) {
        await prefs.remove(k);
      }
    } catch (_) {}
  }
}

class ApiResult {
  final int statusCode; // 0 = gagal jaringan / timeout
  final dynamic json;
  const ApiResult(this.statusCode, this.json);

  bool get isSuccess =>
      statusCode == 200 && json is Map && (json as Map)['success'] == true;
}

/// Client GET dengan token. Aturan logout:
/// - 401 TIDAK langsung logout: dicoba ulang sekali.
/// - Logout hanya jika 401 terjadi dua kali DAN token di perangkat masih token yang sama.
/// - Error jaringan / 5xx / respons aneh TIDAK pernah menyebabkan logout.
class ApiClient {
  static Future<ApiResult> get(String path) async {
    final prefs = await SharedPreferences.getInstance();
    final usedToken = prefs.getString('auth_token');

    if (usedToken == null || usedToken.isEmpty) {
      await AppSession.instance.forceLogout();
      return const ApiResult(401, null);
    }

    for (int attempt = 0; attempt < 2; attempt++) {
      try {
        final response = await http
            .get(
              Uri.parse('${ApiConfig.baseUrl}$path'),
              headers: {
                'Authorization': 'Bearer $usedToken',
                'Accept': 'application/json',
              },
            )
            .timeout(const Duration(seconds: 20));

        if (response.statusCode == 401) {
          if (attempt == 0) {
            await Future.delayed(const Duration(milliseconds: 700));
            continue;
          }
          // Pastikan token yang dipakai masih token aktif (bukan sesi lama).
          final current = (await SharedPreferences.getInstance())
              .getString('auth_token');
          if (current == usedToken) {
            await AppSession.instance.forceLogout();
          }
          return const ApiResult(401, null);
        }

        dynamic body;
        try {
          body = jsonDecode(response.body);
        } catch (_) {}
        return ApiResult(response.statusCode, body);
      } catch (_) {
        if (attempt == 1) return const ApiResult(0, null);
        await Future.delayed(const Duration(milliseconds: 500));
      }
    }
    return const ApiResult(0, null);
  }
}
